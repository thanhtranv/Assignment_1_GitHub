﻿using StudentManagement.Business.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentManagement.Business.Dtos;
using StudentManagement.Data.Contracts;
using StudentManagement.Data.Entities;
using AutoMapper;

namespace StudentManagement.Business
{
    public class CourseBusinessService : BaseBusinessService, ICourseBusinessService
    {
        private IRepository<CategoryEntity> courseRepository;

        public CourseBusinessService(IRepository<CategoryEntity> repo)
        {
            courseRepository = repo;
        }

        public void DeleteCourse(CommentDto courseDto)
        {
            var course = Mapper.Map<CategoryEntity>(courseDto);

            courseRepository.Delete(course);
            courseRepository.SaveChanges();
        }

        public IList<CommentDto> GetAllCourses()
        {
            var course = courseRepository.GetAll();
            var courseDtos = (IList<CommentDto>)Mapper.Map(course, course.GetType(), typeof(IList<CommentDto>));

            return courseDtos;
        }

        public CommentDto GetCourseById(Guid Id)
        {
            var course = courseRepository.GetById(Id);

            return Mapper.Map<CategoryEntity, CommentDto>(course);
        }

        public CommentDto InsertCourse(CommentDto courseDto)
        {
            var course = Mapper.Map<CategoryEntity>(courseDto);
            course = courseRepository.Insert(course);
            courseRepository.SaveChanges();

            return Mapper.Map<CategoryEntity, CommentDto>(course);
        }

        public IList<CommentDto> SearchCourseByName(string courseName, int pageIndex, int pageSize, out int total)
        {
            var course = courseRepository.Search(p => p.Title.Contains(courseName), o => o.Title, pageIndex, pageSize, out total);
            var courseDtos = (IList<CommentDto>)Mapper.Map(course, course.GetType(), typeof(IList<CommentDto>));

            return courseDtos;
        }

        public void UpdateCourse(CommentDto courseDto)
        {
            var course = Mapper.Map<CategoryEntity>(courseDto);

            courseRepository.Update(course);
            courseRepository.SaveChanges();
        }
    }
}
