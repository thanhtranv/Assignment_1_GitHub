namespace StudentManagement.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Student",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        LastName = c.String(),
                        FristName = c.String(),
                        Address = c.String(),
                        Phone = c.String(),
                        DOB = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Enrollment",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        CourseID = c.Int(nullable: false),
                        StudentID = c.Int(nullable: false),
                        Grade = c.Int(),
                        EnrollmentDate = c.DateTime(nullable: false),
                        Course_ID = c.Guid(),
                        Student_ID = c.Guid(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Course", t => t.Course_ID)
                .ForeignKey("dbo.Student", t => t.Student_ID)
                .Index(t => t.Course_ID)
                .Index(t => t.Student_ID);
            
            CreateTable(
                "dbo.Course",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Title = c.String(),
                        Credits = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Enrollment", "Student_ID", "dbo.Student");
            DropForeignKey("dbo.Enrollment", "Course_ID", "dbo.Course");
            DropIndex("dbo.Enrollment", new[] { "Student_ID" });
            DropIndex("dbo.Enrollment", new[] { "Course_ID" });
            DropTable("dbo.Course");
            DropTable("dbo.Enrollment");
            DropTable("dbo.Student");
        }
    }
}
