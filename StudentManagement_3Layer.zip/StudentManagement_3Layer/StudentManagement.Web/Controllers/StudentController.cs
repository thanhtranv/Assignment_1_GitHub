﻿using StudentManagement.Business.Contracts;
using StudentManagement.Business.Dtos;
using StudentManagement.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace StudentManagement.Web.Controllers
{
    public class StudentController : Controller
    {
        private IStudentBusinessService studentService;

        public StudentController(IStudentBusinessService service)
        {
            studentService = service;
        }

        // GET: Student
        public ActionResult Index()
        {
            var student = studentService.GetAllStudents().Select(x => new StudentViewModel()
            {
                FristName = x.FristName,
                LastName = x.LastName,
                DOB = x.DOB.ToString(),
                Phone = x.Phone,
                Address = x.Address
                
            });
            //if (!string.IsNullOrEmpty(searchString))
            //{
            //    student = student.Where(s => s.LastName.ToUpper().Contains(searchString.ToUpper())
            //                            || s.FristName.ToUpper().Contains(searchString.ToUpper())).ToList();
            //}
            return View(student);
        }

        // GET: Student/CreateStudent
        public ActionResult CreateStudent()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateStudent([Bind(Include = "LastName,FristName,Address,Phone,DOB")] CreateStudentViewModel studentModel)
        {
            try
            {
                UserDto studentDto = new UserDto();
                studentDto.FristName = studentModel.FristName;
                studentDto.LastName = studentModel.LastName;
                studentDto.Phone = studentModel.Phone;
                studentDto.DOB = DateTime.Parse(studentModel.DOB);
                studentDto.Address = studentModel.Address;

                if (ModelState.IsValid)
                {
                    studentService.InsertStudent(studentDto);
                    return RedirectToAction("Index");
                    //return new JavaScriptResult { Script = "alert('Successfully registered');" };
                }
            }
            catch (DataException)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }

        public ActionResult EditStudent(Guid id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDto student = studentService.GetStudentById(id);
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditStudent([Bind(Include = "ID,LastName,FristName,Address,Phone,DOB")] UpdateStudentViewModel studentModel)
        {
            try
            {
                UserDto student = studentService.GetStudentById(studentModel.ID);
                student.FristName = studentModel.FristName;
                student.LastName = studentModel.LastName;
                student.DOB = DateTime.Parse(studentModel.DOB);
                student.Address = studentModel.Address;
                student.Phone = studentModel.Phone;

                if (ModelState.IsValid)
                {
                    studentService.UpdateStudent(student);
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }
    }
}